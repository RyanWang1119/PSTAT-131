library(tidyverse)
library(here)
library(tidyr)
library(MASS)
library(ggplot2)


###
nba_all<-read.csv(here('data', 'Seasons_Stats.csv'))
nba_15_16<- nba_all[nba_all$Year == 2015,] 

nba_15_17 <-  subset(nba_all, Year %in% c(2015, 2016))
nba_95_96 <-  subset(nba_all, Year %in% c(1995))
 

write.csv(nba_15_17, 'nba_15_17.csv')

nba_157 <- read.csv(here('data', 'nba_15_17.csv'))
nba_157[c("ALL_STAR")][is.na(nba_157[c("ALL_STAR")])] <- F
nba_15 <- nba_15 %>%
  mutate_at(vars(ALL_STAR), ~replace_na(., F))
nba_15$ALL_STAR <- as_factor(nba_15$ALL_STAR)
write.csv(nba_157, 'nba_15.csv')




